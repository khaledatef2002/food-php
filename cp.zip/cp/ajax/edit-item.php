<?php

include '../../includes/conn.php';
include '../functions/main.php';

if (isset($_POST['id']) && in_array($_POST['active'], array(0, 1, 2)) && isset($_POST['item_name']) && isset($_POST['item_price']) && isset($_POST['item-category']) && isset($_POST['item-discrption']) && in_array($_POST['size_type'], array(0, 1)) && is_logged() && check_user_perm(['items-edit'])) {
    if (!empty($_POST['item_name']) && !empty($_POST['id']) && check_category_exist($_POST['item-category'])) {
        $id = filter_var($_POST['id'], FILTER_SANITIZE_NUMBER_INT);

        $check_id_exist = mysqli_query($GLOBALS['conn'], "SELECT * FROM food_items WHERE id= $id");
        if (mysqli_num_rows($check_id_exist) > 0) {
            $old_info = mysqli_fetch_assoc($check_id_exist);

            $item_name = mysqli_real_escape_string($GLOBALS['conn'], htmlspecialchars($_POST['item_name']));
            $item_cat = filter_var($_POST['item-category'], FILTER_SANITIZE_NUMBER_INT);
            $item_des = mysqli_real_escape_string($GLOBALS['conn'], htmlspecialchars($_POST['item-discrption']));
            $active = filter_var($_POST['active'], FILTER_SANITIZE_NUMBER_INT);

            $item_img = $old_info['img'];

            if (isset($_FILES['image']) && $_FILES["image"]["error"] == 0) {
                $msg = mysqli_real_escape_string($GLOBALS['conn'], upload_image($_FILES['image']));
                if ($msg != "FILE_SIZE_ERROR" && $msg != "FILE_TYPE_ERROR") {
                    if (file_exists("../../" . $old_info['img'])) {
                        unlink("../../" . $old_info['img']);
                    }
                    $item_img = $msg;
                }
            }

            if (isset($_POST['size_type']) && $_POST['size_type'] == 0) {
                $item_price = filter_var($_POST['size_price'][0], FILTER_SANITIZE_NUMBER_FLOAT);
                foreach ($_POST['size_name'] as $key => $val) {
                    if (empty($val) || empty($_POST['size_price'][$key])) {
                        echo json_encode(array("msg" => "error", "body" => "يرجى ادخال جميع بيانات الحجم"));
                        exit();
                    }
                }
            } else {
                $item_price = filter_var($_POST['item_price'], FILTER_SANITIZE_NUMBER_FLOAT);
            }

            if (isset($_POST['option'])) {
                foreach ($_POST['option'] as $key => $val) {
                    if (empty($val['name']) || !in_array($val['type'], array(0, 1))) {
                        echo json_encode(array("msg" => "error", "body" => "يرجى ادخال جميع بيانات الخواص"));
                        exit();
                    }
                    foreach ($val['values_name'] as $k => $v) {
                        if (empty($v)) {
                            echo json_encode(array("msg" => "error", "body" => "يرجى ادخال جميع بيانات الخواص"));
                            exit();
                        }
                    }
                }
            }

            $old_price = filter_var($_POST['item_price_before'], FILTER_SANITIZE_NUMBER_FLOAT);
            $tax = filter_var($_POST['item_tax'], FILTER_SANITIZE_NUMBER_FLOAT);

            if ($active == 2) {
                if (empty($_POST['item_start_date']) || empty($_POST['item_start_time']) || empty($_POST['item_end_date']) || empty($_POST['item_end_time'])) {
                    echo json_encode(array("msg" => "error", "body" => "يرجى ادخال تاريخ البداية والنهاية"));
                    exit();
                }
                $start = strtotime($_POST['item_start_date'] . $_POST['item_start_time']);
                $end = strtotime($_POST['item_end_date'] . $_POST['item_end_time']);
            } else {
                $start = $end = 0;
            }

            $get_old_info = mysqli_query($GLOBALS['conn'], "SELECT * FROM food_items WHERE id=$id");
            $old_item_name = mysqli_fetch_assoc($get_old_info)['title'];

            $insert = mysqli_query($GLOBALS['conn'], "UPDATE food_items SET `from`='$start',`to`='$end', tax='$tax',before_discount='$old_price',cat_id='" . $item_cat . "',title='" . $item_name . "',description='" . $item_des . "',price='" . $item_price . "',img='" . $item_img . "',active='" . $active . "' WHERE id=$id");



            $admin = get_admin_info()['nickname'];

            logg("items", "لقد قام $admin بتعديل بيانات الصنف $old_item_name بمعرض $id");

            $item_id = $id;

            $del_sizes = mysqli_query($GLOBALS['conn'], "DELETE FROM food_items_sizes WHERE item_id=$id");

            if (isset($_POST['size_type']) && $_POST['size_type'] == 0) {
                foreach ($_POST['size_name'] as $key => $val) {
                    $insert_size = mysqli_query($GLOBALS['conn'], "INSERT INTO food_items_sizes(item_id,size_name,size_price) VALUES('" . $item_id . "','" . $val . "','" . $_POST['size_price'][$key] . "')");
                }
            }

            $get_all_options = mysqli_query($GLOBALS['conn'], "SELECT * FROM food_items_options WHERE item_id=$id");
            while ($option = mysqli_fetch_assoc($get_all_options)) {
                $del_options_values = mysqli_query($GLOBALS['conn'], "DELETE FROM food_items_options_values WHERE option_id={$option['id']}");
            }
            $del_options = mysqli_query($GLOBALS['conn'], "DELETE FROM food_items_options WHERE item_id=$id");

            if (isset($_POST['option'])) {
                foreach ($_POST['option'] as $key => $val) {
                    $insert_option = mysqli_query($GLOBALS['conn'], "INSERT INTO food_items_options(item_id,type,name) VALUES('" . $item_id . "','" . $val['type'] . "','" . $val['name'] . "')");

                    $option_id = mysqli_insert_id($GLOBALS['conn']);

                    foreach ($val['values_name'] as $k => $v) {
                        $insert_option = mysqli_query($GLOBALS['conn'], "INSERT INTO food_items_options_values(option_id,name,price) VALUES('" . $option_id . "','" . $v . "','" . $val['values_price'][$k] . "')");
                    }
                }
            }


            echo json_encode(array("msg" => "success", "body" => "تم تحديث بيانات الصنف"));
        } else {
            echo json_encode(array("msg" => "error", "body" => "هذا الصنف غير موجود"));
        }
    } else {
        echo json_encode(array("msg" => "error", "body" => "يرجى ادخال جميع البيانات"));
    }
} else {
    echo json_encode(array("msg" => "error", "body" => "يرجى ادخال جميع البيانات"));
}
