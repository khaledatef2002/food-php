<!--
=========================================================
* Material Dashboard 2 - v3.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard
* Copyright 2023 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://www.creative-tim.com/license)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <?php
    include 'temps/head.php';
    if (!is_logged()) header('Location: login.php');
    if (!check_user_perm(['discounts-add'])) :
        header('Location: 403.php');
        exit;
    endif;
    $get_settings = mysqli_query($GLOBALS['conn'], "SELECT * FROM website_settings WHERE title='currency'");
    $fetch = mysqli_fetch_assoc($get_settings);
    $currency = $fetch['value'];
    ?>
    <title>
        Material Dashboard 2 by Creative Tim
    </title>
</head>

<body class="g-sidenav-show rtl bg-gray-200">
    <?php include 'temps/sidebar.php'; ?>
    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg overflow-x-hidden">
        <?php include 'temps/navbar.php'; ?>
        <!-- End Navbar -->
        <div class="container-fluid py-4">
            <div class="col-lg-10 col-md-8 col-sm-12 mb-md-0 mb-4 mx-auto">
                <div class="card text-center">
                    <h3 class="my-0 font-weight-bold py-2">اضافة خصم</h3>
                </div>
            </div>
            <form action="POST" id="add-discount">
                <div id="sortable" class="row my-4 justify-content-center">
                    <div class="col-lg-5 col-md-4 col-sm-6 mb-2">
                        <div class="card mb-2">
                            <div class="card-body p-3 d-flex flex-column justify-content-between">
                                <div>
                                    <p>
                                        <label for="discount_code" class="font-weight-bold text-dark">كود الخصم:</label>
                                        <input name="discount_code" id="discount_code" type="text" class="form-control border px-2" placeholder="كود الخصم">
                                    </p>
                                    <p class="font-weight-bold text-dark">
                                        <label for="discount_name" class="font-weight-bold text-dark">مسمى الخصم:</label>
                                        <input name="discount_name" id="discount_name" type="text" class="form-control border px-2" placeholder="مسمى الخصم">
                                    </p>
                                    <p class="font-weight-bold text-dark">
                                        <label for="discount_min" class="font-weight-bold text-dark">الحد الادنى للطلب:</label>
                                        <input name="discount_min" id="discount_min" type="number" min="0" step="0.01" class="form-control border px-2" placeholder="الحد الادنى للطلب">
                                    </p>
                                    <p class="font-weight-bold text-dark">
                                        <label for="discount_max_uses" class="font-weight-bold text-dark">الحد الاقصى للاستخدامات:</label>
                                        <input name="discount_max_uses" id="discount_max_uses" type="number" min="0" class="form-control border px-2" placeholder="الحد الاقصى للاستخدامات">
                                    </p>
                                    <p class="font-weight-bold text-dark">
                                        <label for="discount_user_uses" class="font-weight-bold text-dark">الحد الاقصى لاستخدامات العميل الواحد:</label>
                                        <input name="discount_user_uses" id="discount_user_uses" type="number" min="0" class="form-control border px-2" placeholder="الحد الاقصى لاستخدامات العميل الواحد">
                                    </p>
                                    <p class="font-weight-bold text-dark">
                                        <label for="discount_max_price" class="font-weight-bold text-dark">الحد الاقصى للخصم:</label>
                                        <input name="discount_max_price" id="discount_max_price" type="number" min="0" step="0.01" class="form-control border px-2" placeholder="الحد الاقصى لاستخدامات العميل الواحد">
                                    </p>
                                    <div class="d-flex justify-content-evenly hide-radio" data-toggle="buttons">
                                        <label class="btn btn-secondary" for="active1">
                                            <input type="radio" name="active" id="active1" value="1"> مفعل
                                        </label>
                                        <label class="btn btn-secondary" for="active2">
                                            <input type="radio" name="active" id="active2" value="2"> مفعل خلال فترة
                                        </label>
                                        <label class="btn btn-secondary" for="active3">
                                            <input type="radio" name="active" id="active3" value="0"> غير مفعل
                                        </label>
                                    </div>
                                    <div id="active_period" class="flex-row justify-content-between gap-2" style="display:none;">
                                        <p class="font-weight-bold text-dark">
                                            <label for="discount_start" class="font-weight-bold text-dark">بداية الخصم:</label>
                                            <input name="discount_start_date" id="discount_start" type="date" class="form-control border px-2 mb-1">
                                            <input name="discount_start_time" id="discount_start" type="time" class="form-control border px-2">
                                        </p>
                                        <p class="font-weight-bold text-dark">
                                            <label for="discount_end" class="font-weight-bold text-dark">نهاية الخصم:</label>
                                            <input name="discount_end_date" id="discount_end" type="date" class="form-control border px-2 mb-1">
                                            <input name="discount_end_time" id="discount_end" type="time" class="form-control border px-2">
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card mb-2">
                            <div class="card-body p-3 d-flex flex-column justify-content-between">
                                <div>
                                    <p class="text-center fw-bold text-dark">نوع الخصم</p>
                                    <div class="d-flex justify-content-evenly hide-radio" data-toggle="buttons">
                                        <label class="btn btn-secondary" for="discount_type1">
                                            <input type="radio" name="discount_type" id="discount_type1" value="0" checked> خصم الطلب
                                        </label>
                                        <label class="btn btn-secondary" for="discount_type2">
                                            <input type="radio" name="discount_type" id="discount_type2" value="1"> خصم التوصيل
                                        </label>
                                    </div>
                                    <hr class="bg-dark">
                                    <p class="font-weight-bold text-dark">
                                        <label for="discount_value" class="font-weight-bold text-dark">قيمة الخصم:</label>
                                        <input name="discount_value" id="discount_value" type="number" min="0" step="0.01" class="form-control border px-2" placeholder="قيمة الخصم">
                                    </p>
                                    <hr class="bg-dark">
                                    <p class="text-center fw-bold text-dark">نوع القيمة</p>
                                    <div class="d-flex justify-content-evenly hide-radio" data-toggle="buttons">
                                        <label class="btn btn-secondary" for="discount_value1">
                                            <input type="radio" name="discount_value_type" value="0" id="discount_value1" checked> خصم عددي (<?php echo $currency; ?>)
                                        </label>
                                        <label class="btn btn-secondary" for="discount_value2">
                                            <input type="radio" name="discount_value_type" value="1" id="discount_value2"> نسبه مئوية (%)
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-4 col-sm-6 mb-2">
                        <div class="card mb-2 clear-after-success">
                            <div class="card-body p-3 d-flex flex-column justify-content-between">
                                <div>
                                    <p class="text-center fw-bold text-dark">شروط المنطقة</p>
                                    <div class="d-flex justify-content-evenly hide-radio" data-toggle="buttons">
                                        <label class="btn btn-secondary" for="location_type1">
                                            <input type="radio" name="location_type" value="0" id="location_type" checked> بدون شروط
                                        </label>
                                        <label class="btn btn-secondary" for="location_type2">
                                            <input type="radio" name="location_type" value="1" id="location_type2"> ساري على مناطق محددة
                                        </label>
                                        <label class="btn btn-secondary" for="location_type3">
                                            <input type="radio" name="location_type" value="2" id="location_type3"> لا يسري على مناطق محددة
                                        </label>
                                    </div>
                                    <div>
                                        <button type="button" class="btn btn-success col-12 mt-3 mb-0" onclick="add_location(this)">اضافة منطقة</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card mb-2 clear-after-success">
                            <div class="card-body p-3 d-flex flex-column justify-content-between">
                                <div>
                                    <p class="text-center fw-bold text-dark">شروط التصنيفات</p>
                                    <div class="d-flex justify-content-evenly hide-radio" data-toggle="buttons">
                                        <label class="btn btn-secondary" for="category_type1">
                                            <input type="radio" name="category_type" value="0" id="category_type1" checked> بدون شروط
                                        </label>
                                        <label class="btn btn-secondary" for="category_type2">
                                            <input type="radio" name="category_type" value="1" id="category_type2"> ساري على تصنيفات محددة
                                        </label>
                                        <label class="btn btn-secondary" for="category_type3">
                                            <input type="radio" name="category_type" value="2" id="category_type3"> لا يسري على تصنيفات محددة
                                        </label>
                                    </div>
                                    <div>
                                        <button type="button" class="btn btn-success col-12 mt-3 mb-0" onclick="add_category(this)">اضافة تصنيف</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card mb-2 clear-after-success">
                            <div class="card-body p-3 d-flex flex-column justify-content-between">
                                <div>
                                    <p class="text-center fw-bold text-dark">شروط الاصناف</p>
                                    <div class="d-flex justify-content-evenly hide-radio" data-toggle="buttons">
                                        <label class="btn btn-secondary" for="items_type1">
                                            <input type="radio" name="items_type" value="0" id="items_type1" checked> بدون شروط
                                        </label>
                                        <label class="btn btn-secondary" for="items_type2">
                                            <input type="radio" name="items_type" value="1" id="items_type2"> ساري على اصناف محددة
                                        </label>
                                        <label class="btn btn-secondary" for="items_type3">
                                            <input type="radio" name="items_type" value="2" id="items_type3"> لا يسري على اصناف محددة
                                        </label>
                                    </div>
                                    <div>
                                        <button type="button" class="btn btn-success col-12 mt-3 mb-0" onclick="add_item(this)">اضافة صنف</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card mb-2 clear-after-success">
                            <div class="card-body p-3 d-flex flex-column justify-content-between">
                                <div>
                                    <p class="text-center fw-bold text-dark">شروط العملاء</p>
                                    <div class="d-flex justify-content-evenly hide-radio" data-toggle="buttons">
                                        <label class="btn btn-secondary" for="phone_type1">
                                            <input type="radio" name="phone_type" value="0" id="phone_type1" checked> بدون شروط
                                        </label>
                                        <label class="btn btn-secondary" for="phone_type2">
                                            <input type="radio" name="phone_type" value="1" id="phone_type2"> ساري لعملاء محددين
                                        </label>
                                        <label class="btn btn-secondary" for="phone_type3">
                                            <input type="radio" name="phone_type" value="2" id="phone_type3"> لا يسري على عملاء محددين
                                        </label>
                                    </div>
                                    <div>
                                        <button type="button" class="spinner-button-loading btn btn-success col-12 mt-3 mb-0" onclick="add_phone(this)"><span class="content-button-loading">اضافة عميل</span>
                                            <div class="lds-dual-ring"></div>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center col-12">
                    <button type="submit" class="btn bg-gradient-success text-white my-1 py-1 col-lg-8 col-md-8 col-sm-6 fw-bold fs-5">اضافة</button>
                </div>
            </form>
        </div>
        <?php include 'temps/footer.php'; ?>
    </main>

    <?php include 'temps/jslibs.php'; ?>
    <script>
        $("form#add-discount").submit(function(e) {
            e.preventDefault()
            var form = this
            var data = new FormData(form)
            $.ajax({
                url: 'ajax/add-discount.php',
                type: 'POST',
                data: data,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    $(form).find("button[type='submit']").prop("disabled", true)
                },
                success: function(data) {
                    console.log(data)
                    var response = JSON.parse(data)
                    if (response.msg == "success") {
                        Swal.fire({
                            icon: "success",
                            text: "تم اضافة الخصم بنجاح"
                        })
                        $(form).find("input:not([type='radio'])").val("")
                        $(form).find("input[type='radio'][value='0']").prop("checked", true)
                        $(".clear-after-success .card-body > div div:last-of-type div").remove()
                    } else if (response.msg == "error") {
                        $(form).find("button[type='submit']").prop("disabled", false)
                        Swal.fire({
                            icon: "error",
                            text: response.body
                        })
                    }
                }
            })
        })

        $("input[name='active']").change(function() {
            if ($(this).val() == 2) {
                $("#active_period").slideDown();
            } else {
                $("#active_period").slideUp();
            }
        })

        function add_location(me) {
            $(me).before(`
            <div>
                <label for="locations_data" class="font-weight-bold text-dark">اختر المنطقة:</label>
                <div class="d-flex align-items-center my-0">
                    <select name="locations_data[]" id="locations_data" type="text" class="form-control border px-2">   
                        <?php
                        $get_branches = mysqli_query($GLOBALS['conn'], "SELECT * FROM food_branches");
                        while ($branch = mysqli_fetch_assoc($get_branches)) {
                            $get_locations = mysqli_query($GLOBALS['conn'], "SELECT * FROM food_locations WHERE branch_id='" . $branch['id'] . "'");
                        ?>
                            <optgroup label="<?php echo $branch['branch_name']; ?>">
                                <?php while ($loc = mysqli_fetch_assoc($get_locations)) { ?>
                                    <option value="<?php echo $loc['id']; ?>"><?php echo $loc['name']; ?></option>
                                <?php } ?>
                            </optgroup>  
                        <?php } ?>
                    </select>
                    <i class="fas fa-remove me-2 text-danger" role="button" onclick="$(this).parent().parent().remove()"></i>
                </div>
            </div>
        `)
        }

        function add_category(me) {
            $(me).before(`
            <div>
                <label for="categories_data" class="font-weight-bold text-dark">اختر التصنيف:</label>
                <div class="d-flex align-items-center my-0">
                    <select name="categories_data[]" id="categories_data" type="text" class="form-control border px-2">   
                        <?php
                        $get_cat = mysqli_query($GLOBALS['conn'], "SELECT *, (SELECT COUNT(*) FROM food_items WHERE food_items.cat_id = food_categories.id) AS count FROM food_categories");
                        while ($cat = mysqli_fetch_assoc($get_cat)) {
                        ?>
                            <option value="<?php echo $cat['id']; ?>"><?php echo $cat['category_name']; ?> (<?php echo $cat['count']; ?> صنف) - <?php echo ($cat['active'] == 1) ? 'مفعل' : 'غير مفعل'; ?></option>
                        <?php } ?>
                    </select>
                    <i class="fas fa-remove me-2 text-danger" role="button" onclick="$(this).parent().parent().remove()"></i>
                </div>
            </div>
        `)
        }

        function add_item(me) {
            $(me).before(`
            <div>
                <label for="items_data" class="font-weight-bold text-dark">اختر النصف:</label>
                <div class="d-flex align-items-center my-0">
                    <select name="items_data[]" id="items_data" type="text" class="form-control border px-2">
                        <?php
                        $get_cat = mysqli_query($GLOBALS['conn'], "SELECT * FROM food_categories WHERE (SELECT COUNT(*) FROM food_items WHERE food_items.cat_id = food_categories.id) > 0");
                        while ($cat = mysqli_fetch_assoc($get_cat)) {
                            $get_items = mysqli_query($GLOBALS['conn'], "SELECT * FROM food_items WHERE cat_id='" . $cat['id'] . "'");
                        ?>
                            <optgroup label="<?php echo $cat['category_name']; ?>">
                                <?php while ($item = mysqli_fetch_assoc($get_items)) { ?>
                                    <option value="<?php echo $item['id']; ?>"><?php echo $item['title']; ?> - <?php echo ($item['active'] == 1) ? 'مفعل' : 'غير مفعل'; ?></option>
                                <?php } ?>
                            </optgroup>                                          
                        <?php } ?>
                    </select>
                    <i class="fas fa-remove me-2 text-danger" role="button" onclick="$(this).parent().parent().remove()"></i>
                </div>
            </div>
        `)
        }

        function add_phone(me) {
            $(me).before(`
            <div>
                <label class="font-weight-bold text-dark">ادخل رقم العميل:</label>
                <div class="d-flex align-items-center my-0">
                    <input name="phones_data[]" class="form-control border px-2 d-flex align-items-center my-0" placeholder="رقم العميل">
                    <i class="fas fa-remove me-2 text-danger" role="button" onclick="$(this).parent().parent().remove()"></i>
                </div>
            </div>
        `)
        }
    </script>
</body>

</html>